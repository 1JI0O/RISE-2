"""
Helper functions of the robot URDF model (Flexiv bimanual + Robotiq 2F-85).

Authors: Hongjie Fang.
"""

import os
import math
import numpy as np
import kinpy as kp


_GRAV_URDF_KEYWORDS = (
    "grav_base_link",
    "finger_width_joint",
    "gripper_grav",
    "left_robot_grav",
    "flexiv-gn01",
)


def calc_robotiq_state(open_length):
    return 0.725 - math.asin(open_length / 0.1143)


def convert_robotiq_gripper_joint_state(gripper_width):
    gripper_width = np.clip(gripper_width, 0, 0.085)
    state = calc_robotiq_state(gripper_width)

    return {
        'finger_joint': state,
        'left_outer_finger_joint': 0, 
        'left_inner_knuckle_joint': state, 
        'left_inner_finger_joint': -state, 
        'right_inner_knuckle_joint': -state, 
        'right_inner_finger_joint': state, 
        'right_outer_knuckle_joint': -state, 
        'right_outer_finger_joint': 0
    }


def convert_grav_gripper_joint_state(gripper_width):
    gripper_width = float(np.clip(gripper_width, 0.0, 0.1))
    outer = gripper_width * 9.404 - 0.155

    return {
        "finger_width_joint": gripper_width,
        "left_outer_knuckle_joint": outer,
        "left_inner_knuckle_joint": outer,
        "left_inner_finger_joint": -outer,
        "right_outer_knuckle_joint": outer,
        "right_inner_knuckle_joint": outer,
        "right_inner_finger_joint": -outer,
    }


def _is_grav_urdf(urdf_file=None, urdf_text=None):
    urdf_file_str = "" if urdf_file is None else str(urdf_file).lower()
    if any(keyword in urdf_file_str for keyword in _GRAV_URDF_KEYWORDS):
        return True

    if urdf_text is None and urdf_file is not None and os.path.isfile(urdf_file):
        with open(urdf_file, "r", encoding="utf-8") as f:
            urdf_text = f.read()
    urdf_text = "" if urdf_text is None else str(urdf_text).lower()
    return any(keyword in urdf_text for keyword in _GRAV_URDF_KEYWORDS)


def convert_joint_states_single(
    joint,
    joint_cfgs,
    is_rad = True,
    urdf_file = None,
    **kwargs
):
    joint_states = {}

    for idx in range(joint_cfgs.num_robot_joints):
        joint_states["joint{}".format(idx + 1)] = joint[idx]
        if not is_rad:
            joint_states["joint{}".format(idx + 1)] = joint[idx] / 180.0 * np.pi
    
    gripper_width = joint[joint_cfgs.num_robot_joints]
    if _is_grav_urdf(urdf_file=urdf_file, urdf_text=kwargs.get("urdf_text")):
        gripper_joint_states = convert_grav_gripper_joint_state(gripper_width)
    else:
        gripper_joint_states = convert_robotiq_gripper_joint_state(gripper_width)

    return {**joint_states, **gripper_joint_states}


def convert_joint_states(
    left_joint, 
    right_joint, 
    left_joint_cfgs,
    right_joint_cfgs,
    is_rad = True,
    seperate = False,
    urdf_file = None,
    **kwargs
):
    left_joint_states = convert_joint_states_single(
        left_joint,
        left_joint_cfgs,
        is_rad=is_rad,
        urdf_file=urdf_file,
        **kwargs,
    )
    right_joint_states = convert_joint_states_single(
        right_joint,
        right_joint_cfgs,
        is_rad=is_rad,
        urdf_file=urdf_file,
        **kwargs,
    )
    
    if seperate:
        return left_joint_states, right_joint_states

    joint_states = {}
    for key, value in left_joint_states.items():
        joint_states["left_{}".format(key)] = value
    for key, value in right_joint_states.items():
        joint_states["right_{}".format(key)] = value
    return joint_states


def forward_kinematic_single(
    joint,
    joint_cfgs,
    is_rad = True,
    urdf_file = os.path.join("airexo", "urdf_models", "robot", "left_robot_inhand.urdf"),
    with_visuals_map = True,
    **kwargs
):
    """
    Forward kinematic of single robot arm.

    Parameters
    - joint: joint encoder readings of the robot;
    - joint_cfgs: joint configurations of the robot;
    - is_rad: whether the joint value is represented in radius;
    - urdf_file: the urdf file of the robot;
    - with_visuals_map: whether to return visuals map.

    Returns:
    - transforms: the transformations matrix of each mesh w.r.t. robot base;
    - visuals_map: the mapping to retrieve the corresponding mesh name.
    """

    with open(urdf_file, "r", encoding="utf-8") as f:
        urdf_text = f.read()
    model_chain = kp.build_chain_from_urdf(urdf_text.encode('utf-8'))

    joint_states = convert_joint_states_single(
        joint = joint,
        joint_cfgs = joint_cfgs,
        is_rad = is_rad,
        urdf_file = urdf_file,
        urdf_text = urdf_text,
        **kwargs
    )

    if with_visuals_map:
        return model_chain.forward_kinematics(joint_states), model_chain.visuals_map()
    else:
        return model_chain.forward_kinematics(joint_states)


def forward_kinematic(
    left_joint, 
    right_joint,
    left_joint_cfgs,
    right_joint_cfgs,
    is_rad = True,
    urdf_file = os.path.join("airexo", "urdf_models", "robot", "robot.urdf"),
    with_visuals_map = True,
    **kwargs
):
    """
    Forward kinematic of dual robot arm.

    Parameters:
    - left_joint: left joint encoder readings of the robot;
    - right_joint: right joint encoder readings of the robot;
    - left_joint_cfgs: left joint configurations of the robot;
    - right_joint_cfgs: right joint configurations of the robot;
    - is_rad: whether the joint value is represented in radius;
    - urdf_file: the urdf file of the robot;
    - with_visuals_map: whether to return visuals map.

    Returns:
    - transforms: the transformations matrix of each mesh w.r.t. robot base;
    - visuals_map: the mapping to retrieve the corresponding mesh name.
    """

    with open(urdf_file, "r", encoding="utf-8") as f:
        urdf_text = f.read()
    model_chain = kp.build_chain_from_urdf(urdf_text.encode('utf-8'))

    joint_states = convert_joint_states(
        left_joint = left_joint,
        right_joint = right_joint,
        left_joint_cfgs = left_joint_cfgs,
        right_joint_cfgs = right_joint_cfgs,
        is_rad = is_rad,
        seperate = False,
        urdf_file = urdf_file,
        urdf_text = urdf_text,
        **kwargs
    )

    if with_visuals_map:
        return model_chain.forward_kinematics(joint_states), model_chain.visuals_map()
    else:
        return model_chain.forward_kinematics(joint_states)
